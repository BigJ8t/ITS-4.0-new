import './style.css';
import { createHotelScene } from './scene.js';
import { scenario } from './scenario.js';

const $ = (id)=>document.getElementById(id);
const hotel = createHotelScene($('scene'));
let chosen = null;
let attempts = 0;
try { attempts = Number(localStorage.getItem('itsphere-attempts') || 0) || 0; } catch { /* optional local storage */ }
function counter(){ $('trialCounter').textContent=`Tentativi: ${attempts}`; }
counter();
function renderChoices(){
  $('choices').replaceChildren();
  for(const opt of scenario.choices){
    const btn=document.createElement('button');btn.className='choice';btn.type='button';btn.setAttribute('aria-pressed',String(chosen===opt.id));
    const badge=document.createElement('span');badge.className='choice-letter';badge.textContent=String.fromCharCode(65+scenario.choices.indexOf(opt));
    const text=document.createElement('span');text.textContent=opt.label;btn.append(badge,text);
    btn.addEventListener('click',()=>{chosen=opt.id;$('confirmBtn').disabled=false;renderChoices();});
    if(chosen===opt.id)btn.classList.add('selected');$('choices').append(btn);
  }
}
renderChoices();
$('confirmBtn').addEventListener('click',()=>{
  const result=scenario.choices.find(item=>item.id===chosen);if(!result)return;
  attempts++;counter();try{localStorage.setItem('itsphere-attempts',String(attempts));}catch{}
  $('resultTag').textContent=result.tag;$('resultTitle').textContent=result.title;$('resultBody').textContent=result.body;$('coachText').textContent=result.coach;
  $('metrics').replaceChildren();
  for(const m of result.metrics){const line=document.createElement('div');line.className='metric';const label=document.createElement('span');label.textContent=m.label;
    const value=document.createElement('strong');value.textContent=`${m.value>0?'+':''}${m.value} punti`;value.className=m.value>=0?'positive':'negative';line.append(label,value);$('metrics').append(line)}
  $('decisionArea').classList.add('hidden');$('resultArea').classList.remove('hidden');$('resultArea').scrollIntoView({behavior:'smooth',block:'nearest'});
});
$('retryBtn').addEventListener('click',()=>{chosen=null;renderChoices();$('confirmBtn').disabled=true;$('resultArea').classList.add('hidden');$('decisionArea').classList.remove('hidden');});
const modal=$('helpModal');$('helpBtn').addEventListener('click',()=>modal.classList.remove('hidden'));
function close(){modal.classList.add('hidden')}$('closeHelp').addEventListener('click',close);$('startBtn').addEventListener('click',close);
modal.addEventListener('click',e=>{if(e.target===modal)close()});window.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
window.addEventListener('beforeunload',()=>hotel.dispose());
