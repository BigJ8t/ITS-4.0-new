import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const C = {navy:0x0c1927, wall:0x24313c, wood:0x39251e, gold:0xd7aa68, marble:0xd9d1c5, teal:0x21c8d4, black:0x12171c};

export function createHotelScene(container) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1a2632);
  scene.fog = new THREE.FogExp2(0x1a2632, 0.018);
  const camera = new THREE.PerspectiveCamera(56, 1, 0.1, 160);
  camera.position.set(7.2, 3.5, 9.3);
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference:'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.5;
  container.appendChild(renderer.domElement);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.target.set(0,1.75,-2.1); controls.enableDamping=true; controls.dampingFactor=.075;
  controls.maxPolarAngle=Math.PI/2.05; controls.minDistance=2.5; controls.maxDistance=19;
  controls.maxAzimuthAngle=Math.PI/2.6; controls.minAzimuthAngle=-Math.PI/2.6;

  const mat=(color,roughness=.76, metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
  const floorMat=mat(C.marble,.19,.12), dark=mat(C.black,.24,.18), wood=mat(C.wood), gold=mat(C.gold,.32,.8), navy=mat(0x182a3b), teal=new THREE.MeshStandardMaterial({color:C.teal,emissive:0x087d8b,emissiveIntensity:.28,roughness:.38,metalness:.55});
  const white=mat(0xf1e9e0,.8), glass=new THREE.MeshPhysicalMaterial({color:0x8ab9c6,transparent:true,opacity:.31,roughness:.03,metalness:.12,side:THREE.DoubleSide});
  const addBox=(x,y,z,w,h,d,m,shadow=true)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=shadow;o.receiveShadow=true;scene.add(o);return o};
  const addSphere=(x,y,z,r,m)=>{const o=new THREE.Mesh(new THREE.SphereGeometry(r,18,12),m);o.position.set(x,y,z);o.castShadow=true;scene.add(o);return o};
  const cyl=(x,y,z,r1,r2,h,m,segments=20)=>{const o=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,segments),m);o.position.set(x,y,z);o.castShadow=true;scene.add(o);return o};
  const light=(x,y,z,power,color=0xffe3bf)=>{const l=new THREE.PointLight(color,power,12,2);l.position.set(x,y,z);scene.add(l)};

  // Base, walls and high ceiling inspired by boutique hospitality interiors.
  addBox(0,-.13,0,24,.26,22,floorMat);
  addBox(0,4.7,0,24,.22,22,mat(0x8f8274));
  addBox(0,2.4,-9.3,24,5,.24,wood);
  addBox(-10.2,2.4,0,.24,5,22,mat(0x73665d));
  addBox(10.2,2.4,0,.24,5,22,mat(0x726155));
  // patterned stone floor insets
  for(let z=-8;z<11;z+=2.4) for(let x=-10;x<11;x+=2.4) {
    const v=addBox(x,.007,z,2.36,.012,2.36,mat((Math.round(x+z)%3===0)?0xc9c5bd:0xded7ca,.2),false);v.receiveShadow=true;
  }
  for(let k=-10;k<=10;k+=2.4) addBox(k,.02,0,.025,.009,22,gold,false);
  // back wall reception set: vertical battens and central dark statement wall
  for(let x=-10;x<10;x+=.55) addBox(x,2.5,-9.11,.17,5,.13,mat(0x5c3d2a));
  addBox(0,2.8,-9.03,10,3.9,.24,dark);
  for(let x=-4.8;x<5;x+=2.4) addBox(x,2.8,-8.88,.026,3.8,.02,gold,false);
  addBox(0,4.55,-8.85,9,.065,.08,gold);
  // sign on statement wall
  const makeText=(text,w,h,{font='bold 108px Georgia',fill='#efd1a0',bg=null}={})=>{
    const cv=document.createElement('canvas');cv.width=1200;cv.height=240;const ctx=cv.getContext('2d');
    if(bg){ctx.fillStyle=bg;ctx.fillRect(0,0,cv.width,cv.height)};
    ctx.fillStyle=fill;ctx.font=font;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,600,120);
    const texture=new THREE.CanvasTexture(cv);texture.colorSpace=THREE.SRGBColorSpace;
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:texture,transparent:!bg,depthWrite:false}));return mesh;
  };
  const name=makeText('Spazio Origine',6.5,1.2,{font:'italic bold 118px Georgia'});name.position.set(0,3.55,-8.71);scene.add(name);
  const subtitle=makeText('HOSPITALITY   •   EXPERIENCE',5.3,.48,{font:'34px Arial',fill:'#c6a47d'});subtitle.position.set(0,2.98,-8.695);scene.add(subtitle);
  // Reception desk with illuminated plinth
  addBox(0,.67,-6.0,8.8,1.27,1.35,mat(0xbcb4aa,.16,.06));
  addBox(0,1.36,-6,9,.14,1.55,mat(0x393c40,.22,.32));
  addBox(0,.14,-5.31,8.65,.065,.12,teal);
  for(let x=-3.5;x<=3.5;x+=.9) addBox(x,.72,-5.305,.018,1.02,.015,mat(0xa59b92,.45),false);
  addBox(-1.1,1.75,-6.42,1.45,.77,.08,dark);
  addBox(-1.1,1.28,-6.2,.12,.16,.45,metal());
  addBox(2.6,1.45,-6.3,.9,.16,.55,mat(0x554133));
  // Sculptural ceiling lights: rings
  for(let x of [-6.3,0,6.3]) {
    const ring=new THREE.Mesh(new THREE.TorusGeometry(1.36,.047,10,56), new THREE.MeshBasicMaterial({color:0xffd9a1}));
    ring.rotation.x=Math.PI/2;ring.position.set(x,3.95,-2);scene.add(ring);
    for(let q of [-1.1,1.1]) addBox(x+q,4.28,-2,.018,.64,.018,dark,false);
    light(x,3.75,-2,28);
  }
  // glazed arched-window composition along left wall
  for(let z=-6;z<=6;z+=4){
    addBox(-10.02,2.05,z,.07,3.45,2.5,glass,false);
    addBox(-9.95,2,z,.1,3.5,.08,gold,false);
    addBox(-9.95,2,z-1.25,.1,3.5,.08,gold,false);
    addBox(-9.95,2,z+1.25,.1,3.5,.08,gold,false);
    addBox(-9.94,2.6,z,.09,.06,2.55,gold,false);
    light(-8.6,3.2,z,10,0xa0c9ed);
  }
  // Sofa lounge area
  for (let z of [2,5]) {addBox(-6.4,.45,z,3.2,.56,1.4,navy);addBox(-6.4,.82,z-.63,3.2,.95,.35,navy);addBox(-8,.69,z,.38,.7,1.5,navy);addBox(-4.8,.69,z,.38,.7,1.5,navy)}
  cyl(-6,.41,3.6,.78,.82,.38,mat(0x664732));
  for(let [x,z] of [[-8,-3],[8,-5],[7,4],[-7,8]]) {cyl(x,.45,z,.62,.45,.9,mat(0x615247));cyl(x,1.15,z,.08,.12,.6,wood);for(let i=0;i<7;i++){const a=i*Math.PI*2/7;addSphere(x+Math.cos(a)*.48,1.55+Math.sin(i*3)*.12,z+Math.sin(a)*.46,.42,mat(i%2?0x496a43:0x708b59));}}
  // Stylized people, intentionally simplified 3D models rather than fake photorealism.
  function person(x,z,{front=false,coat=0x192c43,hair=0x271b15,skin=0xd8a480}={}){
    const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);
    const skinMat=mat(skin,.78), clothes=mat(coat,.88), hairMat=mat(hair,.96);
    const body=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.78,6,12),clothes);body.position.y=1.18;g.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.245,18,14),skinMat);head.position.y=1.95;g.add(head);
    const hairstyle=new THREE.Mesh(new THREE.SphereGeometry(.254,16,12),hairMat);hairstyle.position.y=2.075;hairstyle.scale.set(1.04,.5,1.04);g.add(hairstyle);
    for(let x2 of [-.18,.18]) {const leg=new THREE.Mesh(new THREE.CylinderGeometry(.12,.15,.82,10),clothes);leg.position.set(x2,.48,0);g.add(leg)}
    for(let sign of [-1,1]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.66,4,10),clothes);arm.position.set(sign*.44,1.23,0);arm.rotation.z=-sign*.22;g.add(arm)}
    g.rotation.y=front?0:Math.PI;return g;
  }
  person(0,-7.26,{front:true,coat:0x22334d,hair:0x271914});
  person(1.9,-3.4,{front:false,coat:0x1c283d,hair:0x1c1413});
  // luggage
  addBox(2.45,.5,-3.2,.61,.95,.4,dark);addBox(2.45,1.11,-3.2,.055,.32,.055,gold,false);addBox(2.45,1.29,-3.2,.35,.04,.04,gold,false);
  // area lighting and AO-like shadow pools
  scene.add(new THREE.HemisphereLight(0xc1d9f4,0x322a23,2.6));
  const sun=new THREE.DirectionalLight(0xffdfb9,3.5);sun.position.set(4,12,5);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-16;sun.shadow.camera.right=16;sun.shadow.camera.top=16;sun.shadow.camera.bottom=-16;scene.add(sun);
  function metal(){return mat(0x7f8490,.3,.65)}
  // Navigation via camera + target preserving orbit geometry.
  const keys=new Set(); const down=(e)=>{if(['INPUT','TEXTAREA','BUTTON'].includes(document.activeElement?.tagName))return;const k=e.key.toLowerCase();if('wasdarrowup arrowdown arrowleft arrowright'.includes(k)){keys.add(k);if(k.startsWith('arrow'))e.preventDefault();}};
  const up=(e)=>keys.delete(e.key.toLowerCase());window.addEventListener('keydown',down);window.addEventListener('keyup',up);
  const moveV=new THREE.Vector3(),forward=new THREE.Vector3(),right=new THREE.Vector3();
  const clock=new THREE.Clock(); let raf=0;let disposed=false;
  function frame(){if(disposed)return;const delta=Math.min(.05,clock.getDelta());
    moveV.set(0,0,0);camera.getWorldDirection(forward);forward.y=0;forward.normalize();right.crossVectors(forward,new THREE.Vector3(0,1,0)).normalize();
    if(keys.has('w')||keys.has('arrowup'))moveV.add(forward);
    if(keys.has('s')||keys.has('arrowdown'))moveV.sub(forward);
    if(keys.has('d')||keys.has('arrowright'))moveV.add(right);
    if(keys.has('a')||keys.has('arrowleft'))moveV.sub(right);
    if(moveV.lengthSq()){moveV.normalize().multiplyScalar(4*delta);const target=controls.target.clone().add(moveV);if(Math.abs(target.x)<8.8&&target.z>-8.3&&target.z<8.6){camera.position.add(moveV);controls.target.add(moveV)}}
    controls.update();renderer.render(scene,camera);raf=requestAnimationFrame(frame);
  }
  const resize=()=>{const {width,height}=container.getBoundingClientRect();if(!width||!height)return;camera.aspect=width/height;camera.updateProjectionMatrix();renderer.setSize(width,height,false)};
  const ro=new ResizeObserver(resize);ro.observe(container);resize();frame();
  return {dispose(){disposed=true;cancelAnimationFrame(raf);ro.disconnect();window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);controls.dispose();renderer.dispose();renderer.domElement.remove();}};
}
