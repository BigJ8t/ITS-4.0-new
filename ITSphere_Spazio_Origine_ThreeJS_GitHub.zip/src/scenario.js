// Modificare questo file per costruire nuovi scenari: nessuna API esterna necessaria.
export const scenario = {
  id: 'ospite-vip-01',
  hotel: 'Spazio Origine',
  choices: [
    {
      id: 'upgrade', label: 'Offri un upgrade immediato',
      tag: 'Risoluzione rapida · costo elevato',
      title: 'L’ospite apprezza la soluzione, ma il margine diminuisce',
      body: 'Proponi una camera di categoria superiore senza verificare prima la disponibilità economica. La soddisfazione può migliorare, ma l’upgrade genera un costo e impatta sull’inventario.',
      metrics: [{label:'Soddisfazione ospite', value: 20}, {label:'Impatto sui costi', value: -25}, {label:'Efficienza operativa', value: 5}],
      coach: 'Prima di offrire un beneficio oneroso, verifica disponibilità, policy aziendale e possibilità di autorizzazione. Quale informazione mancava alla tua scelta?'
    },
    {
      id: 'alternative', label: 'Proponi un servizio alternativo',
      tag: 'Gestione dell’attesa · soluzione equilibrata',
      title: 'L’attesa diventa un’occasione di servizio',
      body: 'Riconosci il disagio e offri un servizio temporaneo compatibile con la policy. Contestualmente, avvisi housekeeping e comunichi un aggiornamento realistico sui tempi.',
      metrics: [{label:'Soddisfazione ospite', value: 15}, {label:'Impatto sui costi', value: -5}, {label:'Efficienza operativa', value: 15}],
      coach: 'Buona combinazione di ascolto e coordinamento. Per migliorare ulteriormente, chiarisci in quanto tempo aggiornerai l’ospite e verifica con il reparto camere.'
    },
    {
      id: 'negotiate', label: 'Concorda un’attesa con beneficio',
      tag: 'Comunicazione assertiva · negoziazione',
      title: 'Un impegno chiaro riduce l’incertezza',
      body: 'Spieghi la situazione senza scaricare responsabilità, concordi un tempo di aggiornamento e proponi un gesto di attenzione proporzionato. La soluzione dipende dalla reale disponibilità della camera.',
      metrics: [{label:'Soddisfazione ospite', value: 10}, {label:'Impatto sui costi', value: -3}, {label:'Efficienza operativa', value: 10}],
      coach: 'La trasparenza è utile solo se il tempo promesso è realistico. Come reagiresti se la camera risultasse ancora indisponibile all’orario concordato?'
    }
  ]
};
